import React from 'react'
import { BButton } from '../style/FormStyle'
import { useNavigate } from 'react-router-dom'

const TestHeader = () => {
  const navigate = useNavigate()
  return (
    <>
      <div style={{display: 'flex', flexDirection: 'column', width: '100%'}}>
        <div style={{display: 'flex', justifyContent:"space-between"}}>
        <div style={{overflow: "auto"}}>
          <span style={{marginBottom:'15px', fontSize: "30px", display:"block"}}>
          {test.t_title}
          </span>
        </div>
        {
          <div style={{display: 'flex', justifyContent: 'flex-end'}}>
          <BButton style={{margin:'0px 10px 0px 10px'}} onClick={()=>{navigate(`/test/update/${t_no}`)}}>
              수정
          </BButton>
          <BButton style={{margin:'0px 10px 0px 10px'}} onClick={testDelete}>
              삭제
          </BButton>
          <BButton style={{margin:'0px 10px 0px 10px'}} onClick={testList}>
              목록
          </BButton>
          </div>
        }
        </div>
        <div style={{display: 'flex', justifyContent: 'space-between', fontSize: '14px'}}>
        <div style={{display: 'flex', flexDirection: 'column'}}>
          <span>작성자 : {"작성자"}</span>
          <span>작성일 : {"2025-07-10"}</span>
        </div>
        <div style={{display: 'flex', flexDirection: 'column', marginRight:'10px'}}>
          <div style={{display: 'flex'}}>
          <span style={{marginRight:'5px'}}>조회수 :</span>
          <div style={{display: 'flex', justifyContent: 'flex-end', width:'30px'}}>{15}</div>
          </div>
        </div>
        </div>
      </div>      
      <hr style={{height: "2px"}}/>
    </>
  )
}

export default TestHeader